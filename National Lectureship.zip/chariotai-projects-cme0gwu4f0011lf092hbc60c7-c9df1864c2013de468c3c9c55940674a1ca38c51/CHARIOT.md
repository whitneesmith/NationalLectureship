---
# Project Overview
- **Project**: Churches of Christ 80th Annual National Lectureship - A website for the event taking place March 8-12, 2026, at the Wyndham Courtland Grand Hotel in Atlanta, GA.
- **Tech Stack**: Not specified
- **Environment**: Not specified

# Theme, Style, and Vibe
- **Theme**: "Here We Stand" based on Ephesians 6:14-16
- **Style**: Professional blue and white color scheme
- **Vibe**: Appropriate for a church organization

# Conversation Context
- **Last Topic**: Not specified
- **Key Decisions**: Not specified
- **User Context**:
  - Technical Level: Not specified
  - Preferences: Not specified
  - Communication: Not specified

# Implementation Status
## Current State
- **Active Feature**: Registration information, hotel details, vendor information, and pricing
- **Progress**: Not specified
- **Blockers**: All attendees must register to comply with insurance regulations

## Code Evolution
- **Recent Changes**: Not specified

# Requirements
- **Implemented**: Not specified
- **In Progress**: Not specified
- **Pending**: Not specified
- **Technical Constraints**: Not specified

# Critical Memory
- **Must Preserve**: Not specified
- **User Requirements**: All attendees must register
- **Known Issues**: Not specified

# Next Actions
- **Immediate**: Not specified
- **Future**: Not specified